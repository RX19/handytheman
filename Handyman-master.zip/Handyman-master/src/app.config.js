const API_BASE_URL = 'http://localhost:3000';

module.exports = API_BASE_URL